package com.example.productregistration.dto;

import com.example.productregistration.domain.Product;

public record ProductResponse(
        Long id,
        String name,
        Integer price,
        Integer number
) {
    public static ProductResponse from(Product product) {return new ProductResponse(product.getId(), product.getName(), product.getPrice(), product.getNumber());}
}
