package com.example.productregistration.exception;

public class ProductException extends RuntimeException {
    private final ErrorCode errorCode;

    public ProductException(ErrorCode errorCode) {
        super(errorCode.getMessage());
        this.errorCode = errorCode;
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }

    public int getStatusCode(){
        return errorCode.getStatus().value();
    }
}
