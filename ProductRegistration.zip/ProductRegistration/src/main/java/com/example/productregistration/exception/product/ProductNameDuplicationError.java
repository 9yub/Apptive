package com.example.productregistration.exception.product;

import com.example.productregistration.exception.ErrorCode;
import com.example.productregistration.exception.ProductException;

public class ProductNameDuplicationError extends ProductException {
    public ProductNameDuplicationError() {
        super(ErrorCode.PRODUCT_NAME_DUPLICATION_ERROR);
    }
}
