package com.example.productregistration.exception.product;

import com.example.productregistration.exception.ErrorCode;
import com.example.productregistration.exception.ProductException;

public class ProductPriceRestrictError extends ProductException {
    public ProductPriceRestrictError() {
        super(ErrorCode.PRODUCT_PRICE_RESTRICT_ERROR);
    }
}
