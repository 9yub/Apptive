//package com.example.productregistration.repository;
//
//import com.example.productregistration.domain.Product;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Optional;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public class MemoryProductRepository implements ProductRepository {
//    private static Map<Long, Product> store = new HashMap<>();
//    private static long sequence = 0L;
//
//    @Override
//    public Product save(Product product) {
//        product.setId(++sequence);
//        store.put(product.getId(), product);
//        return product;
//    }
//
//    @Override
//    public Optional<Product> findById(Long id) {
//        return Optional.ofNullable(store.get(id));
//    }
//
//    @Override
//    public List<Product> findAll() {
//        return new ArrayList<>(store.values());
//    }
//
//    @Override
//    public Optional<Product> findByName(String name) {
//        return store.values().stream()
//                .filter(product -> product.getName().equals(name))
//                .findAny();
//    }
//
//    public void clearStore() {
//        store.clear();
//    }
//}
