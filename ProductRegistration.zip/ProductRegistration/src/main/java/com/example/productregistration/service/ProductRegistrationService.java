package com.example.productregistration.service;


import com.example.productregistration.domain.Product;
import com.example.productregistration.dto.ProductRequest;
import com.example.productregistration.exception.product.ProductNameDuplicationError;
import com.example.productregistration.exception.product.ProductNameRestrictError;
import com.example.productregistration.exception.product.ProductNumberRestrictError;
import com.example.productregistration.exception.product.ProductPriceRestrictError;
import com.example.productregistration.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class ProductRegistrationService {

    private final ProductRepository productRepository;

    @Transactional
    public Product attend(ProductRequest productRequest) {
        Product product = new Product();
        product.setName(productRequest.name());
        product.setPrice(productRequest.price());
        product.setNumber(productRequest.number());

        validateDuplicateProduct(product); // 중복 이름 검증
        validateProductNameLength(product); // 이름 길이 검증
        validateProductNumber(product); // 상품 개수 검증
        validateProductPrice(product);  // 상품 가격 검증

        return productRepository.save(product);
    }

    private void validateDuplicateProduct(Product product) {
        productRepository.findByName(product.getName())
                .ifPresent(m -> {
                    throw new ProductNameDuplicationError();
                });
    }

    private void validateProductNameLength(Product product) {
        String name = product.getName();
        if (name == null || name.isEmpty() || name.length() > 5) {
            throw new ProductNameRestrictError();
        }
    }

    private void validateProductNumber(Product product) {
        int number = product.getNumber();
        if (number < 1 || number > 999) {
            throw new ProductNumberRestrictError();
        }
    }

    private void validateProductPrice(Product product) {
        int price = product.getPrice();
        if (price < 1000 || price > 5000) {
            throw new ProductPriceRestrictError();
        }
    }

    /**
     * 전체 상품 조회
     */
    public List<Product> findProducts() {
        return productRepository.findAll();
    }

    public Optional<Product> findOne(Long productId) {
        return productRepository.findById(productId);
    }

}
