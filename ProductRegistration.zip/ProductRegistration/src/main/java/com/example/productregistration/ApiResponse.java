package com.example.productregistration;

import com.example.productregistration.exception.ProductException;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@Builder
@RequiredArgsConstructor
public class ApiResponse<T> {

    public static final String SUCCESS = "success";
    public static final String FAIL = "fail";
    public static final String ERROR = "error";
    private final String status;
    private final int code;
    private final String message;
    private final T data;

    public static <T> ApiResponse<?> successResponse(T data) {
        return new ApiResponse<>(SUCCESS, HttpStatus.OK.value(), null, data);
    }

    public static <T> ApiResponse<?> successResponseWithMessage(String message, T data) {
        return new ApiResponse<>(SUCCESS, HttpStatus.OK.value(), message, data);
    }

    public static <T> ApiResponse<?> createResponse(T data) {
        return new ApiResponse<>(SUCCESS, HttpStatus.CREATED.value(), null, data);
    }

    public static ApiResponse<?> errorResponse(ProductException e) {
        return new ApiResponse<>(ERROR, e.getStatusCode(), e.getMessage(), null);
    }
}