package com.example.productregistration.dto;

public record ProductRequest(
        String name,
        Integer price,
        Integer number
)
{}
