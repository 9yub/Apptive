package com.example.productregistration.exception.product;

import com.example.productregistration.exception.ErrorCode;
import com.example.productregistration.exception.ProductException;

public class ProductNumberRestrictError extends ProductException {
    public ProductNumberRestrictError() {
        super(ErrorCode.PRODUCT_NUMBER_RESTRICT_ERROR);
    }
}
