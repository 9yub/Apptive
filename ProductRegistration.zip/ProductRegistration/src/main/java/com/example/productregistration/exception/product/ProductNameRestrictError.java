package com.example.productregistration.exception.product;

import com.example.productregistration.exception.ErrorCode;
import com.example.productregistration.exception.ProductException;

public class ProductNameRestrictError extends ProductException {
    public ProductNameRestrictError() {
        super(ErrorCode.PRODUCT_NAME_RESTRICT_ERROR);
    }
}
