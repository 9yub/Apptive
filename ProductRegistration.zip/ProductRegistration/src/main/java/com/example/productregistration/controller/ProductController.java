package com.example.productregistration.controller;

import com.example.productregistration.ApiResponse;
import com.example.productregistration.dto.ProductRequest;
import com.example.productregistration.domain.Product;
import com.example.productregistration.dto.ProductResponse;
import com.example.productregistration.exception.product.ProductNameDuplicationError;
import com.example.productregistration.repository.ProductRepository;
import com.example.productregistration.service.ProductRegistrationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@Transactional
@RequiredArgsConstructor
public class ProductController {
    private final ProductRegistrationService productRegistrationService;

    @GetMapping(value = "/products/new")
    public String showAttendProductForm() {
        return "products/attendProductForm";
    }

    @PostMapping(value = "/products/new")
    public ResponseEntity<ApiResponse<?>> attendProduct(@Valid ProductRequest productRequest) {

        Product attendedProduct = productRegistrationService.attend(productRequest);

        return ResponseEntity.status(HttpStatus.CREATED)
                .contentType(MediaType.APPLICATION_JSON)
                .location(URI.create("/products/new"))
                .body(ApiResponse.createResponse(ProductResponse.from(attendedProduct)));
    }

    @GetMapping(value = "/products")
    public String productList(Model model) {
        List<Product> products = productRegistrationService.findProducts();

        List<ProductResponse> productsResponses = products.stream()
                .map(ProductResponse::from)
                .collect(Collectors.toList());

        model.addAttribute("products", productsResponses);
        return "products/productsList";
    }
}
