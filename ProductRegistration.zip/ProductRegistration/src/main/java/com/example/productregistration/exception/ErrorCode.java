package com.example.productregistration.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@RequiredArgsConstructor
public enum ErrorCode {
    PRODUCT_NAME_DUPLICATION_ERROR(HttpStatus.BAD_REQUEST, "상품의 이름은 중복이 될 수 없습니다."),
    PRODUCT_NAME_RESTRICT_ERROR(HttpStatus.BAD_REQUEST, "상품의 이름은 1~5자 사이여야 합니다."),
    PRODUCT_PRICE_RESTRICT_ERROR(HttpStatus.BAD_REQUEST, "상품의 가격은 1000~5000원 사이여야 합니다."),
    PRODUCT_NUMBER_RESTRICT_ERROR(HttpStatus.BAD_REQUEST, "상품의 수량은 1~999개여야 합니다.");

    private final HttpStatus status;
    private final String message;

}
