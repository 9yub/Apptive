package com.example.productregistration.service;

import com.example.productregistration.domain.Product;
import com.example.productregistration.dto.ProductRequest;
import com.example.productregistration.exception.product.ProductNameDuplicationError;
import com.example.productregistration.exception.product.ProductNameRestrictError;
import com.example.productregistration.exception.product.ProductNumberRestrictError;
import com.example.productregistration.exception.product.ProductPriceRestrictError;
import com.example.productregistration.repository.ProductRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static com.example.productregistration.exception.ErrorCode.*;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
class ProductRegistrationServiceTest {

    @InjectMocks
    private ProductRegistrationService productRegistrationService;

    @Mock
    private ProductRepository productRepository;

    @Test
    @DisplayName("중복된 이름을 가진 상품을 등록하는 경우")
    void 중복된_상품을_등록하는경우_에러() {
        // given
        ProductRequest productRequest = new ProductRequest("정규빈", 2500, 30);
        Product savedProduct = new Product("정규빈", 2500, 30);
        given(productRepository.findByName(productRequest.name())).willReturn(Optional.of(savedProduct));

        // expected
        assertThatThrownBy(()->productRegistrationService.attend(productRequest))
                .isInstanceOf(ProductNameDuplicationError.class)
                .hasMessage(PRODUCT_NAME_DUPLICATION_ERROR.getMessage());
    }

    @Test
    @DisplayName("이름이 1~5자리가 아닐 경우")
    void 이름이_1부터_5자리가_아닌경우_에러() {
        // given
        ProductRequest productRequest = new ProductRequest("정규빈123", 2500, 30);

        // expected
        assertThatThrownBy(()->productRegistrationService.attend(productRequest))
                .isInstanceOf(ProductNameRestrictError.class)
                .hasMessage(PRODUCT_NAME_RESTRICT_ERROR.getMessage());
    }

    @Test
    @DisplayName("개수가 1~999개가 아닐 경우")
    void 개수가_1부터_999개가_아닌경우_에러() {
        // given
        ProductRequest productRequest = new ProductRequest("정규빈", 2500, 1000);

        // expected
        assertThatThrownBy(()->productRegistrationService.attend(productRequest))
                .isInstanceOf(ProductNumberRestrictError.class)
                .hasMessage(PRODUCT_NUMBER_RESTRICT_ERROR.getMessage());
    }

    @Test
    @DisplayName("가격이 1000~5000원이 아닐 경우")
    void 가격이_1000부터_5000원이_아닌경우_에러() {
        // given
        ProductRequest productRequest = new ProductRequest("정규빈", 25000, 30);

        // expected
        assertThatThrownBy(()->productRegistrationService.attend(productRequest))
                .isInstanceOf(ProductPriceRestrictError.class)
                .hasMessage(PRODUCT_PRICE_RESTRICT_ERROR.getMessage());
    }

}